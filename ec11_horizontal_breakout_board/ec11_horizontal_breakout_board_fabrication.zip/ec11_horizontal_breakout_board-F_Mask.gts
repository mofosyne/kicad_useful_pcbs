%TF.GenerationSoftware,KiCad,Pcbnew,9.0.4-9.0.4-0~ubuntu24.04.1*%
%TF.CreationDate,2025-12-27T03:09:44+11:00*%
%TF.ProjectId,ec11_horizontal_breakout_board,65633131-5f68-46f7-9269-7a6f6e74616c,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.4-9.0.4-0~ubuntu24.04.1) date 2025-12-27 03:09:44*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10RoundRect,0.150000X0.625000X-0.150000X0.625000X0.150000X-0.625000X0.150000X-0.625000X-0.150000X0*%
%ADD11RoundRect,0.250000X0.650000X-0.350000X0.650000X0.350000X-0.650000X0.350000X-0.650000X-0.350000X0*%
%ADD12RoundRect,0.250000X-0.512000X0.512000X-0.512000X-0.512000X0.512000X-0.512000X0.512000X0.512000X0*%
%ADD13C,1.524000*%
G04 APERTURE END LIST*
D10*
%TO.C,J50*%
X5025000Y-1460000D03*
X5025000Y-460000D03*
X5025000Y540000D03*
X5025000Y1540000D03*
D11*
X8900000Y-2760000D03*
X8900000Y2840000D03*
%TD*%
D12*
%TO.C,SW3*%
X0Y2500000D03*
D13*
X0Y-2500000D03*
X0Y0D03*
X2500000Y2500000D03*
X2500000Y-2500000D03*
%TD*%
M02*
